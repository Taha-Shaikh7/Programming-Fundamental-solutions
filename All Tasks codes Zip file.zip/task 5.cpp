#include<iostream>
using namespace std;
int main(){
/*Roll No:  
Name:   
01 
Ahmed */
//Lab_Number:  01 
return 0;
}




#include<iostream>
using namespace std;
int main(){
cout << "Welcome to Lab 1 \nBye";

return 0;

}

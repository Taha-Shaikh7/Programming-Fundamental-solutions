#include<iostream>
using namespace std;
int main(){
cout << "Muhammad Taha";
return 0;
}
